package com.example.ma.sm.task.listeners;

public interface OnErrorListener {
  void onError(Exception e);
}
