package ro.ubbcluj.cs.books;

public interface MyCallback {
  void showError(String message);

  void clear();
}
