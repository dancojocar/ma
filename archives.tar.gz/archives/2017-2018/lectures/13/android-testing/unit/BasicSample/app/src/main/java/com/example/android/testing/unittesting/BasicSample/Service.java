package com.example.android.testing.unittesting.BasicSample;

public interface Service {
    boolean login(String user, String pass);
}
