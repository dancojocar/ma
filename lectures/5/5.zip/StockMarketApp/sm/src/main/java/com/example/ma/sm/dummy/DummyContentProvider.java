package com.example.ma.sm.dummy;

public interface DummyContentProvider {
  void showDummyData();
}
