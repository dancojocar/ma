package com.example.ma.sm.task.listeners;

public interface OnSuccessListener<E> {
  void onSuccess(E e);
}
