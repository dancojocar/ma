package com.example.ma.sm.task.listeners;

public interface OnErrorUpdateListener {
  void onError(Exception e);
}
