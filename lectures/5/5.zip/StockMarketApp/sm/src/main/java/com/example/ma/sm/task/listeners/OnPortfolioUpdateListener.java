package com.example.ma.sm.task.listeners;

public interface OnPortfolioUpdateListener {
  void updated();

  void preUpdate();
}
